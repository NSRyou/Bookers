require 'test_helper'

class HomesControllerControllerTest < ActionDispatch::IntegrationTest
  test "should get top" do
    get homes_controller_top_url
    assert_response :success
  end

end
